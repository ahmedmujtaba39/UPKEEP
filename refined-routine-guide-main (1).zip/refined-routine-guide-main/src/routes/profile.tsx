import { createFileRoute } from "@tanstack/react-router";
import { TopBar } from "@/components/TopBar";
import { ChevronRight } from "lucide-react";

export const Route = createFileRoute("/profile")({
  component: ProfilePage,
});

function ProfilePage() {
  const prefs = [
    { k: "Skin type", v: "Combination" },
    { k: "Beard style", v: "Short, defined" },
    { k: "Hair type", v: "Straight, fine" },
    { k: "Fragrance", v: "Woody · vetiver" },
  ];
  const account = [
    { k: "Subscription", v: "Maison Member" },
    { k: "Notifications", v: "Morning · 06:30" },
    { k: "Privacy", v: "Private journal" },
  ];

  return (
    <div className="h-full flex flex-col bg-background">
      <TopBar />
      <main className="flex-1 px-6 pt-2 flex flex-col gap-5 animate-fade-in overflow-y-auto">
        <div className="flex items-center gap-4">
          <div className="w-14 h-14 rounded-full bg-charcoal flex items-center justify-center font-display text-xl text-primary-foreground">
            AL
          </div>
          <div>
            <p className="eyebrow mb-1">Member since 2024</p>
            <h1 className="font-display text-2xl text-graphite leading-none">Augustin Léon</h1>
          </div>
        </div>

        <Section title="Preferences" items={prefs} />
        <Section title="Account" items={account} />

        <button className="text-[11px] tracking-[0.25em] uppercase text-mid hover:text-navy py-2 transition-colors self-start">
          Sign out
        </button>
      </main>
    </div>
  );
}

function Section({ title, items }: { title: string; items: { k: string; v: string }[] }) {
  return (
    <section>
      <p className="eyebrow mb-2 px-1">{title}</p>
      <div className="bg-surface rounded-2xl border border-hairline divide-y divide-hairline">
        {items.map((i) => (
          <button key={i.k} className="w-full flex items-center justify-between px-4 py-3.5 text-left hover:bg-soft-grey/40 transition-colors">
            <span className="text-sm text-charcoal">{i.k}</span>
            <span className="flex items-center gap-2 text-[12px] text-mid">
              {i.v}
              <ChevronRight size={14} strokeWidth={1.25} />
            </span>
          </button>
        ))}
      </div>
    </section>
  );
}
