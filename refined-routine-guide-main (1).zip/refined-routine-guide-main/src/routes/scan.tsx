import { createFileRoute } from "@tanstack/react-router";
import { TopBar } from "@/components/TopBar";
import { useState } from "react";
import { ScanLine, Sparkles } from "lucide-react";

export const Route = createFileRoute("/scan")({
  component: ScanPage,
});

function ScanPage() {
  const [scanned, setScanned] = useState(false);

  return (
    <div className="h-full flex flex-col bg-background">
      <TopBar />
      <main className="flex-1 px-6 pt-2 flex flex-col gap-5 animate-fade-in">
        <div>
          <p className="eyebrow mb-2">Assessment</p>
          <h1 className="font-display text-3xl text-graphite leading-tight">Skin & beard scan</h1>
        </div>

        {/* Scan panel */}
        <div className="relative aspect-[3/4] rounded-2xl border border-hairline bg-gradient-to-b from-soft-grey/40 to-surface overflow-hidden">
          <div className="absolute inset-6 border border-dashed border-mid/50 rounded-xl" />
          <div className="absolute inset-0 flex flex-col items-center justify-center gap-3">
            <div className="w-14 h-14 rounded-full border border-hairline bg-surface flex items-center justify-center">
              <ScanLine size={22} strokeWidth={1.25} className="text-navy" />
            </div>
            <p className="text-[11px] tracking-[0.2em] uppercase text-mid">Scan in natural light</p>
          </div>
          {/* corner ticks */}
          {["top-3 left-3 border-t border-l", "top-3 right-3 border-t border-r", "bottom-3 left-3 border-b border-l", "bottom-3 right-3 border-b border-r"].map((c) => (
            <span key={c} className={`absolute ${c} w-5 h-5 border-charcoal/40`} />
          ))}
        </div>

        {!scanned ? (
          <button
            onClick={() => setScanned(true)}
            className="bg-navy text-primary-foreground rounded-full py-3.5 text-[11px] tracking-[0.25em] uppercase hover:bg-graphite transition-colors"
          >
            Begin scan
          </button>
        ) : (
          <div className="bg-surface rounded-2xl border border-hairline p-5 animate-fade-up">
            <div className="flex items-center gap-2 mb-3">
              <Sparkles size={14} strokeWidth={1.25} className="text-navy" />
              <p className="eyebrow !text-navy">Result</p>
            </div>
            <div className="grid grid-cols-3 gap-3 mb-4">
              {[
                { k: "Skin", v: "Balanced" },
                { k: "Beard", v: "Dry" },
                { k: "Hair", v: "Healthy" },
              ].map((m) => (
                <div key={m.k} className="border border-hairline rounded-lg p-3">
                  <p className="text-[10px] tracking-[0.18em] uppercase text-mid">{m.k}</p>
                  <p className="font-display text-base text-graphite mt-1">{m.v}</p>
                </div>
              ))}
            </div>
            <div className="flex flex-wrap gap-2 mb-4">
              {["+ Hydrating serum", "+ Beard oil"].map((c) => (
                <span key={c} className="text-[11px] tracking-wide text-charcoal border border-hairline rounded-full px-3 py-1.5">
                  {c}
                </span>
              ))}
            </div>
            <button className="w-full bg-navy text-primary-foreground rounded-full py-3 text-[11px] tracking-[0.25em] uppercase hover:bg-graphite transition-colors">
              Apply to routine
            </button>
          </div>
        )}
      </main>
    </div>
  );
}
