import { createFileRoute, Link } from "@tanstack/react-router";
import { TopBar } from "@/components/TopBar";
import { Plus, Droplet } from "lucide-react";

export const Route = createFileRoute("/closet")({
  component: ClosetPage,
});

const categories = [
  { key: "Skin", count: 4 },
  { key: "Beard", count: 2 },
  { key: "Fragrance", count: 3 },
  { key: "Hair", count: 1 },
];

const owned = [
  { name: "Vetiver 17", house: "Maison No. 01", category: "Fragrance", remaining: 72, opened: "Mar 2025" },
  { name: "Sea Foam Cleanser", house: "Maison No. 04", category: "Skin", remaining: 40, opened: "Aug 2025" },
  { name: "Rebuild Night Cream", house: "Hôtel Noir", category: "Skin", remaining: 25, opened: "Sep 2025" },
  { name: "Cedar Beard Balm", house: "Atelier Lin", category: "Beard", remaining: 88, opened: "Oct 2025" },
  { name: "Kaolin Mask", house: "Atelier Lin", category: "Ritual", remaining: 60, opened: "Jul 2025" },
];

function ClosetPage() {
  return (
    <div className="h-full flex flex-col bg-background">
      <TopBar />
      <main className="flex-1 px-6 pt-2 flex flex-col gap-5 animate-fade-in overflow-y-auto">
        <div className="flex items-end justify-between">
          <div>
            <p className="eyebrow mb-2">Your collection</p>
            <h1 className="font-display text-3xl text-graphite leading-tight">The Closet</h1>
          </div>
          <Link
            to="/shop"
            className="inline-flex items-center gap-1.5 text-[10px] tracking-[0.25em] uppercase text-navy"
          >
            <Plus size={12} strokeWidth={1.5} /> Add
          </Link>
        </div>

        <div className="grid grid-cols-4 gap-2">
          {categories.map((c) => (
            <div
              key={c.key}
              className="bg-surface rounded-xl border border-hairline px-2 py-3 text-center"
            >
              <p className="font-display text-xl text-graphite leading-none">{c.count}</p>
              <p className="eyebrow !text-[9px] mt-1.5">{c.key}</p>
            </div>
          ))}
        </div>

        <section>
          <p className="eyebrow mb-2 px-1">In rotation · {owned.length}</p>
          <div className="bg-surface rounded-2xl border border-hairline divide-y divide-hairline">
            {owned.map((p) => (
              <div key={p.name} className="flex items-center gap-4 px-4 py-3.5">
                <div className="w-11 h-11 rounded-lg bg-soft-grey/70 border border-hairline flex items-center justify-center">
                  <Droplet size={14} strokeWidth={1.25} className="text-mid" />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm text-graphite truncate">{p.name}</p>
                  <p className="text-[10px] tracking-[0.18em] uppercase text-mid mt-0.5">
                    {p.house} · Opened {p.opened}
                  </p>
                </div>
                <div className="w-14 text-right">
                  <p className="font-display text-sm text-navy leading-none">{p.remaining}%</p>
                  <div className="mt-1.5 h-[3px] bg-soft-grey rounded-full overflow-hidden">
                    <div
                      className="h-full bg-charcoal"
                      style={{ width: `${p.remaining}%` }}
                    />
                  </div>
                </div>
              </div>
            ))}
          </div>
        </section>
      </main>
    </div>
  );
}
