import { createFileRoute } from "@tanstack/react-router";
import { TopBar } from "@/components/TopBar";
import { useState } from "react";
import { GripVertical, Plus } from "lucide-react";

export const Route = createFileRoute("/routine")({
  component: RoutinePage,
});

const data = {
  Morning: [
    { step: "Cleanse", product: "Foaming wash · Atelier Lin" },
    { step: "Tone", product: "Birch essence" },
    { step: "Moisturize", product: "SPF 30 fluid" },
    { step: "Style beard", product: "Cedar balm" },
    { step: "Fragrance", product: "Vetiver 17" },
  ],
  Evening: [
    { step: "Double cleanse", product: "Oil + foam" },
    { step: "Exfoliate", product: "PHA serum · 2×/week" },
    { step: "Night cream", product: "Rebuild complex" },
    { step: "Beard oil", product: "Sandalwood" },
  ],
  Occasional: [
    { step: "Clay mask", product: "Kaolin · weekly" },
    { step: "Beard trim", product: "Outline + length" },
    { step: "Hand ritual", product: "Cuticle balm" },
  ],
};

type Tab = keyof typeof data;

function RoutinePage() {
  const [tab, setTab] = useState<Tab>("Morning");
  const tabs: Tab[] = ["Morning", "Evening", "Occasional"];

  return (
    <div className="h-full flex flex-col bg-background">
      <TopBar />
      <main className="flex-1 px-6 pt-2 flex flex-col gap-5 animate-fade-in">
        <div>
          <p className="eyebrow mb-2">Rituals</p>
          <h1 className="font-display text-3xl text-graphite leading-tight">Your routines</h1>
        </div>

        <div className="bg-soft-grey/60 rounded-full p-1 grid grid-cols-3">
          {tabs.map((t) => (
            <button
              key={t}
              onClick={() => setTab(t)}
              className={`rounded-full py-2 text-[11px] tracking-[0.2em] uppercase transition-all ${
                tab === t ? "bg-surface text-navy shadow-sm" : "text-dark-grey"
              }`}
              style={{ color: tab === t ? "var(--navy)" : "var(--dark-grey)" }}
            >
              {t}
            </button>
          ))}
        </div>

        <div className="bg-surface rounded-2xl border border-hairline divide-y divide-hairline animate-fade-up">
          {data[tab].map((item, i) => (
            <div key={item.step} className="flex items-center gap-3 px-4 py-4">
              <span className="font-display text-lg text-mid w-6">0{i + 1}</span>
              <div className="flex-1">
                <p className="text-sm text-graphite">{item.step}</p>
                <p className="text-[11px] text-mid tracking-wide mt-0.5">{item.product}</p>
              </div>
              <GripVertical size={16} strokeWidth={1.25} className="text-mid" />
            </div>
          ))}
          <button className="w-full flex items-center justify-center gap-2 py-3.5 text-[11px] tracking-[0.2em] uppercase text-mid hover:text-navy transition-colors">
            <Plus size={14} strokeWidth={1.25} /> Add step
          </button>
        </div>

        <div className="flex gap-3">
          <button className="flex-1 border border-hairline rounded-full py-3 text-[11px] tracking-[0.25em] uppercase text-charcoal hover:border-navy hover:text-navy transition-colors">
            Save
          </button>
          <button className="flex-1 bg-navy text-primary-foreground rounded-full py-3 text-[11px] tracking-[0.25em] uppercase hover:bg-graphite transition-colors">
            Begin
          </button>
        </div>
      </main>
    </div>
  );
}
