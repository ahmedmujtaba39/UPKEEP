import { Link, useLocation } from "@tanstack/react-router";
import { Home, ListChecks, ScanLine, Shirt, BookOpen, User } from "lucide-react";

const tabs = [
  { to: "/", label: "Home", icon: Home },
  { to: "/routine", label: "Routine", icon: ListChecks },
  { to: "/scan", label: "Scan", icon: ScanLine },
  { to: "/closet", label: "Closet", icon: Shirt },
  { to: "/journal", label: "Journal", icon: BookOpen },
  { to: "/profile", label: "Profile", icon: User },
] as const;

export function BottomNav() {
  const { pathname } = useLocation();
  return (
    <nav className="absolute bottom-0 left-0 right-0 border-t border-hairline bg-surface/95 backdrop-blur-md">
      <ul className="flex items-stretch justify-between px-2 pt-2 pb-3">
        {tabs.map(({ to, label, icon: Icon }) => {
          const active = pathname === to;
          return (
            <li key={to} className="flex-1">
              <Link
                to={to}
                className="flex flex-col items-center gap-1 py-1 transition-colors"
              >
                <Icon
                  size={20}
                  strokeWidth={1.25}
                  className={active ? "text-navy" : "text-mid"}
                />
                <span
                  className={`text-[10px] tracking-[0.18em] uppercase ${
                    active ? "text-navy font-medium" : "text-mid"
                  }`}
                >
                  {label}
                </span>
              </Link>
            </li>
          );
        })}
      </ul>
    </nav>
  );
}
