import { Outlet } from "@tanstack/react-router";
import { BottomNav } from "./BottomNav";

export function PhoneShell({ children }: { children?: React.ReactNode }) {
  return (
    <div className="min-h-screen w-full bg-background flex items-center justify-center">
      {/* Mobile-first: fills screen on phones, framed on desktop */}
      <div className="relative w-full max-w-[440px] h-screen md:h-[900px] md:my-8 md:rounded-[40px] md:border md:border-hairline overflow-hidden bg-background md:shadow-[0_30px_80px_-30px_rgba(15,27,39,0.15)]">
        <div className="absolute inset-0 pb-[78px] overflow-hidden">
          {children ?? <Outlet />}
        </div>
        <BottomNav />
      </div>
    </div>
  );
}
