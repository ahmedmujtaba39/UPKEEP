import { createFileRoute, Link } from "@tanstack/react-router";
import { TopBar } from "@/components/TopBar";
import { ArrowUpRight, Check } from "lucide-react";

export const Route = createFileRoute("/")({
  component: Home,
});

function Home() {
  const month = "November";
  const days = 30;
  const today = 18;
  const loggedDays = new Set([1, 2, 3, 5, 6, 7, 8, 9, 10, 12, 13, 14, 15, 16, 17, 18]);
  const streak = 7;

  const routine = [
    { label: "Cleanse", note: "Foaming wash" },
    { label: "Moisturize", note: "SPF 30" },
    { label: "Style beard", note: "Light balm" },
    { label: "Fragrance", note: "Eau de parfum" },
  ];

  const suggested = [
    { name: "Cedar Balm", house: "Maison No. 04" },
    { name: "Sea Cleanser", house: "Atelier Lin" },
    { name: "Vetiver 17", house: "Maison No. 01" },
  ];

  return (
    <div className="h-full flex flex-col bg-background">
      <TopBar showShop />

      <main className="flex-1 px-6 flex flex-col gap-5 animate-fade-in">
        {/* Daily login tracker */}
        <section className="bg-surface rounded-2xl border border-hairline p-5 animate-fade-up">
          <div className="flex items-baseline justify-between mb-4">
            <div>
              <p className="eyebrow mb-1">Ritual</p>
              <h2 className="font-display text-2xl text-graphite leading-none">{month}</h2>
            </div>
            <div className="text-right">
              <p className="eyebrow mb-1">Streak</p>
              <p className="font-display text-2xl text-navy leading-none">{streak} <span className="text-sm text-mid">days</span></p>
            </div>
          </div>

          <div className="grid grid-cols-10 gap-1.5">
            {Array.from({ length: days }).map((_, i) => {
              const day = i + 1;
              const logged = loggedDays.has(day);
              const isToday = day === today;
              return (
                <div
                  key={day}
                  className={[
                    "aspect-square rounded-[3px] transition-all",
                    isToday
                      ? "bg-navy ring-2 ring-navy/20 ring-offset-1 ring-offset-surface"
                      : logged
                      ? "bg-charcoal/85"
                      : "bg-soft-grey/70 border border-hairline",
                  ].join(" ")}
                  style={{
                    backgroundColor: isToday
                      ? "var(--navy)"
                      : logged
                      ? "var(--charcoal)"
                      : "var(--soft-grey)",
                  }}
                />
              );
            })}
          </div>

          <div className="mt-4 flex items-center justify-between text-[10px] tracking-[0.2em] uppercase text-mid">
            <span>{loggedDays.size} of {days} logged</span>
            <span>Today · 18</span>
          </div>
        </section>

        {/* Morning routine */}
        <section className="bg-surface rounded-2xl border border-hairline p-5 animate-fade-up delay-100">
          <div className="flex items-center justify-between mb-4">
            <div>
              <p className="eyebrow mb-1">This morning</p>
              <h3 className="font-display text-xl text-graphite leading-none">Daybreak ritual</h3>
            </div>
            <span className="text-[10px] tracking-[0.2em] uppercase text-mid">06:42</span>
          </div>

          <ul className="space-y-2.5 mb-4">
            {routine.map((step, i) => (
              <li key={step.label} className="flex items-center gap-3">
                <span className="flex items-center justify-center w-5 h-5 rounded-full border border-hairline text-[10px] text-mid font-medium">
                  {i + 1}
                </span>
                <div className="flex-1 flex items-baseline justify-between border-b border-hairline pb-2 last:border-0 last:pb-0">
                  <span className="text-sm text-charcoal">{step.label}</span>
                  <span className="text-[11px] text-mid tracking-wide">{step.note}</span>
                </div>
              </li>
            ))}
          </ul>

          <Link
            to="/routine"
            className="group flex items-center justify-center gap-2 bg-navy text-primary-foreground rounded-full py-3 text-[11px] tracking-[0.25em] uppercase hover:bg-graphite transition-colors"
          >
            Start routine
            <ArrowUpRight size={14} strokeWidth={1.5} className="transition-transform group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
          </Link>
        </section>

        {/* Suggested products */}
        <section className="animate-fade-up delay-200">
          <div className="flex items-baseline justify-between mb-2 px-1">
            <p className="eyebrow">Curated for you</p>
            <Link to="/shop" className="text-[10px] tracking-[0.2em] uppercase text-mid hover:text-navy">
              View all
            </Link>
          </div>
          <div className="bg-surface rounded-2xl border border-hairline divide-y divide-hairline">
            {suggested.map((p) => (
              <div key={p.name} className="flex items-center justify-between px-4 py-3">
                <div>
                  <p className="text-sm text-graphite">{p.name}</p>
                  <p className="text-[10px] tracking-[0.18em] uppercase text-mid mt-0.5">{p.house}</p>
                </div>
                <Check size={14} strokeWidth={1.25} className="text-mid" />
              </div>
            ))}
          </div>
        </section>
      </main>
    </div>
  );
}
