import { Link } from "@tanstack/react-router";
import { ShoppingBag } from "lucide-react";

interface Props {
  title?: string;
  showShop?: boolean;
  back?: string;
}

export function TopBar({ title, showShop = false, back }: Props) {
  return (
    <header className="flex items-center justify-between px-6 pt-5 pb-4">
      <div className="flex items-center gap-2">
        {back ? (
          <Link to={back} className="text-xs tracking-[0.2em] uppercase text-mid hover:text-navy">
            Back
          </Link>
        ) : (
          <Link to="/" className="flex items-baseline gap-1.5">
            <span className="font-display text-[22px] leading-none text-navy">Maison</span>
            <span className="eyebrow !text-[9px]">No. 01</span>
          </Link>
        )}
      </div>
      {title && (
        <span className="eyebrow absolute left-1/2 -translate-x-1/2 mt-1">{title}</span>
      )}
      {showShop ? (
        <Link
          to="/shop"
          className="flex items-center gap-2 text-[11px] tracking-[0.2em] uppercase text-charcoal hover:text-navy transition-colors"
        >
          <ShoppingBag size={14} strokeWidth={1.25} />
          Shop
        </Link>
      ) : (
        <span className="w-6" />
      )}
    </header>
  );
}
