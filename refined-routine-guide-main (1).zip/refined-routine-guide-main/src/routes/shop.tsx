import { createFileRoute } from "@tanstack/react-router";
import { TopBar } from "@/components/TopBar";
import { Plus } from "lucide-react";

export const Route = createFileRoute("/shop")({
  component: ShopPage,
});

const products = [
  { name: "Vetiver 17", house: "Maison No. 01", category: "Fragrance", price: "€140" },
  { name: "Cedar Beard Balm", house: "Atelier Lin", category: "Beard", price: "€38" },
  { name: "Sea Foam Cleanser", house: "Maison No. 04", category: "Skin", price: "€42" },
  { name: "Rebuild Night Cream", house: "Hôtel Noir", category: "Skin", price: "€68" },
  { name: "Kaolin Mask", house: "Atelier Lin", category: "Ritual", price: "€34" },
];

function ShopPage() {
  return (
    <div className="h-full flex flex-col bg-background">
      <TopBar back="/" />
      <main className="flex-1 px-6 pt-2 flex flex-col gap-5 animate-fade-in overflow-y-auto">
        <div>
          <p className="eyebrow mb-2">Curated objects</p>
          <h1 className="font-display text-3xl text-graphite leading-tight">The Shop</h1>
        </div>

        <div className="flex gap-2 overflow-x-auto -mx-1 px-1">
          {["All", "Skin", "Beard", "Fragrance", "Ritual"].map((c, i) => (
            <button
              key={c}
              className={`shrink-0 text-[11px] tracking-[0.2em] uppercase px-3.5 py-1.5 rounded-full border ${
                i === 0 ? "bg-navy text-primary-foreground border-navy" : "border-hairline text-charcoal"
              }`}
            >
              {c}
            </button>
          ))}
        </div>

        <div className="bg-surface rounded-2xl border border-hairline divide-y divide-hairline">
          {products.map((p) => (
            <div key={p.name} className="flex items-center gap-4 px-4 py-4">
              <div className="w-14 h-14 rounded-lg bg-soft-grey/70 border border-hairline" />
              <div className="flex-1 min-w-0">
                <p className="text-sm text-graphite truncate">{p.name}</p>
                <p className="text-[11px] tracking-[0.18em] uppercase text-mid mt-0.5">{p.house}</p>
              </div>
              <div className="text-right">
                <p className="font-display text-base text-graphite leading-none">{p.price}</p>
                <button className="mt-1.5 inline-flex items-center gap-1 text-[10px] tracking-[0.2em] uppercase text-navy">
                  <Plus size={11} strokeWidth={1.5} /> Add
                </button>
              </div>
            </div>
          ))}
        </div>
      </main>
    </div>
  );
}
