import { createFileRoute } from "@tanstack/react-router";
import { TopBar } from "@/components/TopBar";

export const Route = createFileRoute("/journal")({
  component: JournalPage,
});

function JournalPage() {
  const days = 35;
  const today = 18;
  const logged = new Set([1,2,3,5,6,7,8,9,10,12,13,14,15,16,17,18]);
  const evening = new Set([2,3,7,8,9,13,14,15,17]);

  return (
    <div className="h-full flex flex-col bg-background">
      <TopBar />
      <main className="flex-1 px-6 pt-2 flex flex-col gap-5 animate-fade-in">
        <div>
          <p className="eyebrow mb-2">Journal</p>
          <h1 className="font-display text-3xl text-graphite leading-tight">November, in quiet</h1>
        </div>

        <div className="grid grid-cols-3 gap-3">
          {[
            { k: "Streak", v: "7" },
            { k: "Logged", v: "16d" },
            { k: "Routines", v: "94%" },
          ].map((s) => (
            <div key={s.k} className="bg-surface border border-hairline rounded-2xl p-3">
              <p className="eyebrow">{s.k}</p>
              <p className="font-display text-2xl text-graphite mt-1 leading-none">{s.v}</p>
            </div>
          ))}
        </div>

        <div className="bg-surface rounded-2xl border border-hairline p-5 animate-fade-up">
          <div className="flex items-center justify-between mb-4">
            <p className="text-sm text-graphite">Consistency</p>
            <div className="flex items-center gap-3 text-[10px] tracking-[0.18em] uppercase text-mid">
              <span className="flex items-center gap-1.5"><i className="w-2 h-2 rounded-sm" style={{ background: "var(--charcoal)" }}/>AM</span>
              <span className="flex items-center gap-1.5"><i className="w-2 h-2 rounded-sm" style={{ background: "var(--navy)" }}/>PM</span>
            </div>
          </div>
          <div className="grid grid-cols-7 gap-1.5">
            {Array.from({ length: days }).map((_, i) => {
              const d = i + 1;
              const am = logged.has(d);
              const pm = evening.has(d);
              const bg = pm ? "var(--navy)" : am ? "var(--charcoal)" : "var(--soft-grey)";
              return (
                <div
                  key={d}
                  className={`aspect-square rounded-[3px] ${d === today ? "ring-2 ring-navy/30 ring-offset-1 ring-offset-surface" : ""}`}
                  style={{ backgroundColor: bg }}
                />
              );
            })}
          </div>
        </div>

        <div className="bg-surface rounded-2xl border border-hairline divide-y divide-hairline">
          {[
            { d: "Today", t: "Morning ritual complete", n: "4 steps · 6 min" },
            { d: "Yesterday", t: "Evening ritual complete", n: "3 steps · 4 min" },
            { d: "16 Nov", t: "Scan logged", n: "Beard · dry" },
          ].map((e) => (
            <div key={e.t} className="px-4 py-3 flex items-baseline justify-between">
              <div>
                <p className="text-sm text-graphite">{e.t}</p>
                <p className="text-[11px] text-mid tracking-wide mt-0.5">{e.n}</p>
              </div>
              <span className="text-[10px] tracking-[0.2em] uppercase text-mid">{e.d}</span>
            </div>
          ))}
        </div>
      </main>
    </div>
  );
}
